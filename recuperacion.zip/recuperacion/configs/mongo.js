'use strict'
const mongoose = require('mongoose');

